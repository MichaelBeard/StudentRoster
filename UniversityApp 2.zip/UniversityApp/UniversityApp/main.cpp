//
//  main.cpp
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#include <iostream>
#include "roster.hpp"
#include "student.hpp"
using namespace std;

int main(int argc, const char * argv[]) {
    // insert code here...
    const string studentData[] =

    {"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY", "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK", "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE", "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY", "A5,Michael,Beard,mbear22@wgu.edu,27,30,33,40,SOFTWARE"};
    
    cout << "Scripting and Programming - Applications";
    cout << " - C867" << endl;
    cout << "Language: C++" << endl;
    cout << "Student ID: 001152465" << endl;
    cout << "Name: Michael Beard" << endl;
    
    Roster classRoster;
    for(int i = 0; i < 5; i++){
        classRoster.parse(studentData[i]);
}
    classRoster.printAll();

    classRoster.printInvalidEmails();

     

    //loop through classRosterArray and for each element:
    
    for(int i = 0; i < 5; i++){
    classRoster.printAverageDaysInCourse(classRoster.classRosterArray[i]->GetStudentID());
    }
     

    classRoster.printByDegreeProgram(SOFTWARE);

    classRoster.remove("A3");

    classRoster.printAll();

    classRoster.remove("A3");

    //expected: the above line should print a message saying such a student with this ID was not found.
    
    
    return 0;
}
