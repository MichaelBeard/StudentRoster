//
//  roster.cpp
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#include "roster.hpp"
#include "student.hpp"
#include "degree.h"
using namespace std;

Roster::~Roster(){
    cout << "DESTROYING!" << endl;
}
//Function to access student info array and get data separated by commas.
void Roster::parse(string studentInfo){
    
    //rhs (Right Hand Side) will get the value(string position) which the first comma appears at.
    int rhs = studentInfo.find(",");
    
    //after finding the first comma, substring will find any data before the comma AND after the beginning of the string.
    string id = studentInfo.substr(0, rhs);
    
    //lhs (Left Hand Side) will position us ahead of the data we just found (ID).
    int lhs = rhs + 1;
    
    //Now rhs is attempting to find a comma, this time BEGINNING from lhs.
    rhs = studentInfo.find(",", lhs);
    
    //Ahead of the ID we just found, we can now find the student's first name using substring.
    //Substract the position of the second comma we found by the position of the left hand side to get the data in between both commas.
    string fname = studentInfo.substr(lhs, rhs-lhs);
    
    //Repeat the process to get the last name.
    lhs = rhs + 1;
    rhs = studentInfo.find(",", lhs);
    string lname = studentInfo.substr(lhs, rhs-lhs);
    
    //Repeat the process to get the email address.
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    string eaddress = studentInfo.substr(lhs, rhs-lhs);
    
    //Repeat the process to get the age of the student.
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    //stoi (String to Integer) is used to convert the age we see in string format into integer format.
    int ageofstudent = stoi(studentInfo.substr(lhs, rhs-lhs));
    
    //Repeat the process to get the first amount of days in course
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    int d1 = stoi(studentInfo.substr(lhs, rhs-lhs));
    
    //Repeat the process to get the second amount of days in course
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    int d2 = stoi(studentInfo.substr(lhs, rhs-lhs));
    
    //Repeat the process to get the third amount of days in course
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    int d3 = stoi(studentInfo.substr(lhs, rhs-lhs));
    
    //By default, we're setting the degree program for a student to be Security.
    //This has no function outside of initializing the variable.
    DegreeProgram d = SECURITY;
    
    //Repeat the same process as above.
    lhs = rhs + 1;
    rhs = studentInfo.find("," , lhs);
    
    //However, now we use multiple if statements to set the Student's actual degree program.
    if(studentInfo.substr(lhs, rhs-lhs) == "SOFTWARE") d = SOFTWARE;
    if(studentInfo.substr(lhs, rhs-lhs) == "SECURITY") d = SECURITY;
    if(studentInfo.substr(lhs, rhs-lhs) == "NETWORK") d = NETWORK;
    
    //Call the add function with the variables we've collected.
    add(id, fname, lname, eaddress, ageofstudent, d1, d2, d3, d);
}
//Add function.
void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeType)
{
    //Our student constructor only accepts arrays of the days in course, which we have collected individually.
    //In order to rectify that we'll simply create an array of these integers and call it daysarr.
    int daysarr[3] = {daysInCourse1, daysInCourse2, daysInCourse3};
    
    //Creating new student objects based on the values we've collected.
    //Everytime the add function is called, lastIndex will be incremented. This will essentially "push back" the objects.
    classRosterArray[++lastIndex] = new Student(studentID, firstName, lastName, emailAddress, age, daysarr, degreeType);
    
}
//Prints out all students that have been added to the class roster
void Roster::printAll(){
    //This for loop will access every student object's print function, which has been defined in its respective class.
    for(int i = 0; i <= lastIndex; i++){
        classRosterArray[i]->Print();
    }
}
//Prints out a student object if their degree matches the given parameter.
void Roster::printByDegreeProgram(DegreeProgram degreeType){
    //This for loop will check if the student's degree type matches the parameter and if so will call the print function for that student.
    for(int i = 0; i <= lastIndex; i++){
        if(classRosterArray[i]->GetDegreeProgram() == degreeType) classRosterArray[i]->Print();
        }
    cout << endl;
}
//Function to find the average days a student has spent in courses.
void Roster::printAverageDaysInCourse(string studentID){
    //initializing a variable that will ultimately hold the final value we need.
    int average = 0;
    //initializing a boolean variable in case the student ID is not present in our roster, in which case this value will stay as false.
    bool found = false;
    
    // for loop to find and calculate a student's average days.
    for(int i = 0; i <= lastIndex; i++){
        if(classRosterArray[i]->GetStudentID() == studentID){
            found = true;
             average = (classRosterArray[i]->GetDaysLeft()[0] + classRosterArray[i]->GetDaysLeft()[1] + classRosterArray[i]->GetDaysLeft()[2]) / 3.0;
            cout << "Student ID: " << studentID << endl;
            cout << "Average days in course are: " << average << endl;
        break;
        }
    }
    //If our boolean variable, "found", stays as false, then that must mean we have not found a student based on the student ID given.
    if(!found){
        cout << "Student ID not found." << endl;
    }
}
        
//Note: A valid email should include an @ sign AND '.' and should not include a whitespace ' '
//This function finds and prints out email addresses that don't follow the given format.
void Roster::printInvalidEmails(){
    //This boolean variable will change to true if an invalid email address is found.
    bool validity = false;
    //For loop that finds and prints invalid email addresses based on the if condtition's parameters.
    for(int i = 0; i <= lastIndex; i++){
        
        //using the get functions built in our student class, we'll get each student's email address
        //if either an '@' sign OR a '.' are EQUAL to string::npos, then that means they are absent and thus invalid
        //ALSO if a whitespace (' ')  IS NOT EQUAL to string::npos, then that means there is a whitespace present, therefore this email must be invalid.
        if((classRosterArray[i]->GetEmailAddress().find('@') == string::npos || classRosterArray[i]->GetEmailAddress().find('.') == string::npos) || (classRosterArray[i]->GetEmailAddress().find(' ') != string::npos)){
            cout <<"FOUND INVALID EMAIL: " << classRosterArray[i]->GetEmailAddress() << endl;
            validity = true;
            }
        }
    //if our boolean variable stays at false, then that must mean our for loop didn't find any invalid email addresses.
    if(!validity) cout<<"NO INVALID EMAILS FOUND!"<< endl;
    }

//Function to remove a student from the roster, given their student ID.

void Roster::remove(string studentID){
    //As before, we're using a boolean variable.
    bool removed = false;
    
    //This for loop will first check if a student with the given studentID exists
    //If so then we change our boolean variable's value to 'true'
    for(int i = 0; i <= lastIndex; i++){
        if(classRosterArray[i]->GetStudentID() == studentID){
            removed = true;
            //The following code will make sure our memory is allocated correctly.
            //If our for loop iterator ('i') is less than the number of students - 1
            if (i < numStudents - 1){
                //Then we will set a temporary student object to hold the student we need to remove.
                Student* temp = classRosterArray[i];
                //The student we need to remove will be changed to the student at the last index of our array
                classRosterArray[i] = classRosterArray[numStudents-1];
                //now we put the temporary value holding the student we need to remove at the back of the array
                classRosterArray[numStudents-1] = temp;
            }
            //This hides the last student object as we are essentially making the array smaller.
            lastIndex--;
            }
        
    }
    //if our boolean variable ('removed') stays as false then that must mean the student object doesn't exist anyways.
    if (!removed) {
        cout << "Error: Student not found." << endl;
        
    }
    
}

