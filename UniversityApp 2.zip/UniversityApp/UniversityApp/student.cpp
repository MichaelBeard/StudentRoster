//
//  student.cpp
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#include "student.hpp"
#include "degree.h"
using namespace std;
//Basic Constructor
Student::Student(){
    this->studentID = "";
    this->firstName = "";
    this->lastName = "";
    this->emailAddress = "";
    this->age = 0;
    for(int i = 0; i < 3; i++) this->daysLeft[i] = 0;
    this->degreeType = DegreeProgram::SOFTWARE;
}
//Constructor with parameters.
Student::Student(string studentID, string firstName, string lastName, string emailAddress, int age, int daysLeft[], DegreeProgram degreeType){
    this->studentID = studentID;
    this->firstName = firstName;
    this->lastName = lastName;
    this->emailAddress = emailAddress;
    this->age = age;
    for(int i = 0; i < 3; i++) this->daysLeft[i] = daysLeft[i];
    this->degreeType = degreeType;
}
//add destructor
Student::~Student(){
    cout << "DESTROYING!" << endl;
    
}
//Functions to get Student values if needed.
string Student::GetStudentID(){return this->studentID;}
string Student::GetFirstName(){return this->firstName;}
string Student::GetLastName(){return this->lastName;}
string Student::GetEmailAddress(){return this->emailAddress;}
int Student::GetAge(){return this->age;}
int* Student::GetDaysLeft(){return this->daysLeft;}
DegreeProgram Student::GetDegreeProgram(){return this->degreeType;}

//Functions to set student values as necessary.
void Student::SetStudentID(string studentID){
    this->studentID;
    return;
}

void Student::SetFirstName(string firstName){
    this->firstName;
    return;
}

void Student::SetLastName(string lastName){
    this->lastName;
    return;
}

void Student::SetEmailAddress(string emailAddress){
    this->emailAddress;
    return;
}

void Student::SetAge(int age){
    this->age;
    return;
}

void Student::SetDaysLeft(int daysLeft[]){
    for(int i = 0; i < 3; i++){
        this->daysLeft[i] = daysLeft[i];
        }
    return;
}

void Student::SetDegreeProgram(DegreeProgram degreeType){
    this->degreeType = degreeType;
    return;
    
    
}
//A function to print student values in a clear manner.
void Student::Print(){
    cout << this->GetStudentID() << '\t';
    cout << this->GetFirstName() << '\t';
    cout << this->GetLastName() << '\t';
    cout << this->GetEmailAddress() << '\t';
    cout << this->GetAge() << '\t';
    cout << this->GetDaysLeft()[0] << ',';
    cout << this->GetDaysLeft()[1] << ',';
    cout << this->GetDaysLeft()[2] << '\t';
    cout << degreeTypeStrings[this->GetDegreeProgram()] << '\n';
}
