//
//  degree.h
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#ifndef degree_h
#define degree_h
#include <string>
using namespace std;

enum DegreeProgram{SECURITY,NETWORK,SOFTWARE};
static const string degreeTypeStrings[] = {"SECURITY", "NETWORK", "SOFTWARE"};


#endif /* degree_h */
