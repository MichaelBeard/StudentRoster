//
//  roster.hpp
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#ifndef roster_hpp
#define roster_hpp
#include "student.hpp"
#include "degree.h"
#include <stdio.h>

using namespace std;
class Roster{
public:
    void parse(string row);
    void add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeType);
    void remove(string studentID);
    void printAll();
    void printAverageDaysInCourse(string studentID);
    void printInvalidEmails();
    void printByDegreeProgram(DegreeProgram degreeType);
    ~Roster();
    const static int numStudents = 5;
    Student* classRosterArray[numStudents];
    int lastIndex = -1;
    
};

#endif /* roster_hpp */

