//
//  student.hpp
//  UniversityApp
//
//  Created by Michael Beard on 1/12/21.
//

#ifndef student_hpp
#define student_hpp
#include "degree.h"
#include <string>
#include <stdio.h>
#include <iostream>
using namespace std;
class Student{


public:
    Student();
    Student(string studentID, string firstName, string lastName, string emailAddress, int age, int daysLeft[], DegreeProgram degreeType);
    ~Student();
    
    string GetStudentID();
    string GetFirstName();
    string GetLastName();
    string GetEmailAddress();
    int GetAge();
    int* GetDaysLeft();
    DegreeProgram GetDegreeProgram();
    void SetStudentID(string studentID);
    void SetFirstName(string firstName);
    void SetLastName(string lastName);
    void SetEmailAddress(string emailAddress);
    void SetAge(int age);
    void SetDaysLeft(int daysLeft[]);
    void SetDegreeProgram(DegreeProgram program);
    void Print();
    
private:
    string studentID;
    string firstName;
    string lastName;
    string emailAddress;
    int age;
    int daysLeft[3];
    DegreeProgram degreeType;
    

    
};

#endif /* student_hpp */
